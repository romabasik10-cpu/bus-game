extends VehicleBody3D
## Заглушка машины (Этап 4 заменит на полноценную с 5 авто).
## Управление с клавиатуры для теста на ПК: W/S — газ/тормоз, A/D — руль, Space — ручник.

const MAX_STEER := 0.5

@onready var fl: VehicleWheel3D = $WheelFL
@onready var fr: VehicleWheel3D = $WheelFR

func _physics_process(delta: float) -> void:
	var throttle := Input.get_axis("ui_down", "ui_up")
	var steer := Input.get_axis("ui_right", "ui_left")
	engine_force = throttle * 2000.0
	steering = move_toward(steering, steer * MAX_STEER, delta * 3.0)
	if Input.is_action_pressed("ui_select"):
		brake = 20.0
	else:
		brake = 0.0
