extends Node3D
## Тестовая стартовая сцена: проверяем, что Global работает.

func _ready() -> void:
	print("Машина: ", Global.selected_car, " | Качество: ", Global.quality)
	$Label.text = "Проект запущен!\nМашина: %s" % Global.selected_car
