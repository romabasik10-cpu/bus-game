extends Node
## Глобальные настройки. Доступны из любого скрипта как Global.

const SAVE_PATH := "user://save.cfg"

## Список машин (в Этапе 4 заменим на Resource-файлы)
const CAR_IDS := ["hatchback", "sport", "suv", "pickup", "drift"]

## Типы управления
enum Controls { BUTTONS, TILT }
## Качество графики
enum Quality { LOW, MEDIUM, HIGH }

signal settings_changed

var selected_car: String = "hatchback"
var car_color: Color = Color.RED
var control_type: Controls = Controls.BUTTONS
var quality: Quality = Quality.MEDIUM
var master_volume: float = 0.8   # 0.0 ... 1.0


func _ready() -> void:
	load_settings()
	apply_settings()


## Применяем настройки к движку
func apply_settings() -> void:
	# Громкость через общую аудио-шину Master
	AudioServer.set_bus_volume_db(0, linear_to_db(master_volume))
	var vp := get_viewport()
	match quality:
		Quality.LOW:
			vp.scaling_3d_scale = 0.6      # рисуем в меньшем разрешении
			vp.msaa_3d = Viewport.MSAA_DISABLED
		Quality.MEDIUM:
			vp.scaling_3d_scale = 0.8
			vp.msaa_3d = Viewport.MSAA_DISABLED
		Quality.HIGH:
			vp.scaling_3d_scale = 1.0
			vp.msaa_3d = Viewport.MSAA_2X
	settings_changed.emit()


func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("player", "car", selected_car)
	cfg.set_value("player", "color", car_color)
	cfg.set_value("settings", "controls", control_type)
	cfg.set_value("settings", "quality", quality)
	cfg.set_value("settings", "volume", master_volume)
	cfg.save(SAVE_PATH)


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return  # файла нет — первый запуск
	selected_car = cfg.get_value("player", "car", selected_car)
	car_color = cfg.get_value("player", "color", car_color)
	control_type = cfg.get_value("settings", "controls", control_type)
	quality = cfg.get_value("settings", "quality", quality)
	master_volume = cfg.get_value("settings", "volume", master_volume)
