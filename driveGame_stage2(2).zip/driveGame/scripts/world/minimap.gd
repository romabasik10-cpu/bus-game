extends Control
## Мини-карта: рисует квадрат карты, кольцо дороги и точку игрока.

const MAP_SIZE := 512.0

func _ready() -> void:
	custom_minimum_size = Vector2(140, 140)
	size = Vector2(140, 140)
	position = Vector2(16, 16)   # левый верхний угол


func update_car(pos: Vector3, rot_y: float) -> void:
	queue_redraw()
	_car_pos = pos
	_car_rot = rot_y

var _car_pos: Vector3
var _car_rot: float


func _draw() -> void:
	var s := size.x / MAP_SIZE  # масштаб: вся карта в квадрате
	# Фон
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.1, 0.25, 0.1))
	# Кольцо дороги (примерный контур)
	var pts := PackedVector2Array()
	var road := [
		Vector2(-160, -120), Vector2(-40, -170), Vector2(90, -150),
		Vector2(170, -60), Vector2(150, 60), Vector2(60, 150),
		Vector2(-80, 160), Vector2(-170, 60),
	]
	for p in road:
		pts.append(world_to_map(p))
	draw_polyline(pts, Color(0.6, 0.6, 0.6), 3.0)
	# Дрифт-площадка
	draw_circle(world_to_map(Vector2.ZERO), 55 * s, Color(0.4, 0.4, 0.42))
	# Игрок — треугольник, смотрит по направлению движения
	var cp := world_to_map(Vector2(_car_pos.x, _car_pos.z))
	var dir := Vector2(-sin(_car_rot), -cos(_car_rot))
	var right := Vector2(-dir.y, dir.x)
	draw_colored_polygon(PackedVector2Array([
		cp + dir * 8, cp - dir * 5 + right * 4, cp - dir * 5 - right * 4
	]), Color(1, 0.3, 0.2))


func world_to_map(p: Vector2) -> Vector2:
	var s := size.x / MAP_SIZE
	return Vector2(size.x * 0.5 + p.x * s, size.y * 0.5 + p.y * s)
