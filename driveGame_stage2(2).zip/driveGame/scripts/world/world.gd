extends Node3D
## Главная сцена мира: ландшафт + дороги + объекты + вода + границы + респавн + миникарта.

const MAP_HALF := 256.0          # граница карты
const RESPAWN_Y := -20.0         # упал ниже — респавн
const FLIP_TIME := 3.0           # секунд на боку/крыше — респавн

var car: VehicleBody3D
var flip_timer := 0.0
var last_good_transform: Transform3D

@onready var minimap: Control = $UI/Minimap


func _ready() -> void:
	# Создаём мир кодом (проще поддерживать, чем .tscn вручную)
	add_child(load("res://scenes/world/terrain.tscn").instantiate())
	add_child(load("res://scenes/world/roads.tscn").instantiate())
	add_child(load("res://scenes/world/scatter.tscn").instantiate())
	add_water()
	add_bounds()
	setup_lighting()
	spawn_car()


func _process(delta: float) -> void:
	if car == null:
		return
	# Респавн при падении
	if car.global_position.y < RESPAWN_Y:
		respawn()
		return
	# Респавн при перевороте
	var up := car.global_transform.basis.y
	if up.y < 0.3:
		flip_timer += delta
		if flip_timer > FLIP_TIME:
			respawn()
	else:
		flip_timer = 0.0
	# Запоминаем хорошую позицию (на колёсах, внутри карты)
	if up.y > 0.9 and car.global_position.y > 0:
		last_good_transform = car.global_transform
	if minimap:
		minimap.update_car(car.global_position, car.global_rotation.y)


func spawn_car() -> void:
	var scene := load("res://scenes/car/car.tscn") as PackedScene
	car = scene.instantiate()
	car.global_position = Vector3(0, 2, 60)
	add_child(car)
	last_good_transform = car.global_transform


func respawn() -> void:
	car.global_transform = last_good_transform
	car.linear_velocity = Vector3.ZERO
	car.angular_velocity = Vector3.ZERO
	flip_timer = 0.0


func add_water() -> void:
	# Озеро — плоская синяя плоскость в низине
	var water := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(140, 100)
	water.mesh = plane
	water.position = Vector3(0, 0.3, -210)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.1, 0.3, 0.55, 0.8)
	m.roughness = 0.1
	m.metallic = 0.3
	water.material_override = m
	add_child(water)


func add_bounds() -> void:
	# Невидимые стены по краям карты
	for i in range(4):
		var wall := StaticBody3D.new()
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = Vector3(MAP_HALF * 2 + 20, 40, 2)
		shape.shape = box
		wall.add_child(shape)
		match i:
			0: wall.position = Vector3(0, 20, -MAP_HALF)
			1: wall.position = Vector3(0, 20, MAP_HALF)
			2:
				wall.position = Vector3(-MAP_HALF, 20, 0)
				wall.rotation_degrees.y = 90
			3:
				wall.position = Vector3(MAP_HALF, 20, 0)
				wall.rotation_degrees.y = 90
		add_child(wall)


func setup_lighting() -> void:
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	add_child(sun)
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_SKY
	e.sky = Sky.new()
	e.sky.sky_material = ProceduralSkyMaterial.new()
	e.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	e.fog_enabled = true
	e.fog_light_color = Color(0.8, 0.85, 0.9)
	e.fog_density = 0.0015
	env.environment = e
	add_child(env)
