extends Node3D
## Генератор ландшафта: сетка вершин + шум для холмов.
## Размер карты: SIZE x SIZE метров, сетка STEP метров между вершинами.

const SIZE := 512.0        # метров
const STEP := 4.0          # шаг сетки (меньше = детальнее, но больше полигонов)
const HEIGHT := 14.0       # максимальная высота холмов

@onready var mesh_instance: MeshInstance3D = $MeshInstance3D
@onready var static_body: StaticBody3D = $StaticBody3D

func _ready() -> void:
	generate()


func generate() -> void:
	var n := int(SIZE / STEP) + 1
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var noise := FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.008
	noise.fractal_octaves = 4
	# Сглаживание у краёв карты, чтобы не было резких обрывов
	for z in range(n):
		for x in range(n):
			var px := (x - n/2.0) * STEP
			var pz := (z - n/2.0) * STEP
			var h := noise.get_noise_2d(px, pz) * HEIGHT
			# приподнимаем края карты (горы-ограждение)
			var edge := max(abs(px), abs(pz)) / (SIZE * 0.5)
			if edge > 0.85:
				h += (edge - 0.85) * 60.0
			st.set_uv(Vector2(x, z) * 0.25)
			st.add_vertex(Vector3(px, h, pz))
	# треугольники
	for z in range(n - 1):
		for x in range(n - 1):
			var i := z * n + x
			st.add_index(i)
			st.add_index(i + n)
			st.add_index(i + 1)
			st.add_index(i + 1)
			st.add_index(i + n)
			st.add_index(i + n + 1)
	st.generate_normals()
	var mesh := st.commit()
	mesh_instance.mesh = mesh
	# Коллизия: упрощённая копия сетки
	var shape := ConcavePolygonShape3D.new()
	shape.set_faces(mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX])
	static_body.add_child(CollisionShape3D.new())
	static_body.get_child(0).shape = shape
