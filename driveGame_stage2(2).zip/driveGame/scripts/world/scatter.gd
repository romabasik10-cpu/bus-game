extends Node3D
## Расстановка деревьев и камней через MultiMesh (1 draw call на тип объекта).

const TREE_COUNT := 300
const ROCK_COUNT := 80

func _ready() -> void:
	spawn_trees()
	spawn_rocks()


func spawn_trees() -> void:
	# Низкополигональное дерево: цилиндр + конус
	var trunk := CylinderMesh.new()
	trunk.top_radius = 0.25
	trunk.bottom_radius = 0.35
	trunk.height = 3.0
	var leaves := ConeMesh.new()
	leaves.radius = 2.2
	leaves.height = 5.0
	# Объединяем в один меш через ArrayMesh
	var tree_mesh := ArrayMesh.new()
	for src in [trunk, leaves]:
		var st := SurfaceTool.new()
		st.append_from(src, 0, Transform3D.IDENTITY)
		st.commit(tree_mesh)
	var mm := MultiMesh.new()
	mm.mesh = tree_mesh
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.instance_count = TREE_COUNT
	var rng := RandomNumberGenerator.new()
	rng.seed = 42
	for i in range(TREE_COUNT):
		var pos := random_pos(rng)
		var t := Transform3D(Basis.from_euler(Vector3(0, rng.randf() * TAU, 0)), pos)
		var s := rng.randf_range(0.8, 1.6)
		t.basis = t.basis.scaled(Vector3.ONE * s)
		mm.set_instance_transform(i, t)
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.material_override = make_tree_mat()
	add_child(mi)


func spawn_rocks() -> void:
	var rock := SphereMesh.new()
	rock.radius = 1.0
	rock.height = 1.4
	var mm := MultiMesh.new()
	mm.mesh = rock
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.instance_count = ROCK_COUNT
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in range(ROCK_COUNT):
		var pos := random_pos(rng)
		var t := Transform3D(Basis.from_euler(Vector3(rng.randf(), rng.randf() * TAU, 0)), pos)
		t.basis = t.basis.scaled(Vector3.ONE * rng.randf_range(0.5, 2.0))
		mm.set_instance_transform(i, t)
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.45, 0.45, 0.48)
	mi.material_override = m
	add_child(mi)


func random_pos(rng: RandomNumberGenerator) -> Vector3:
	# Не ставим объекты на дрифт-площадку (центр) и на дороги-кольцо
	while true:
		var x := rng.randf_range(-240, 240)
		var z := rng.randf_range(-240, 240)
		if Vector2(x, z).length() < 70:
			continue  # центр — площадка
		return Vector3(x, 0, z)


func make_tree_mat() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.2, 0.45, 0.15)
	return m
