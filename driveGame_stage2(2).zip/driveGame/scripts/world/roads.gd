extends Node3D
## Дороги: замкнутая трасса (кольцо) + площадка для дрифта + трамплины + мост.
## Дорога = плоская лента (CSGPolygon3D) вдоль Curve3D, приподнята над землёй на 0.05 м.

const ROAD_WIDTH := 10.0
const ROAD_LIFT := 0.06

func _ready() -> void:
	build_ring_road()
	build_drift_pad()
	build_ramps()
	build_bridge()


func build_ring_road() -> void:
	var curve := Curve3D.new()
	# Точки кольцевой трассы (x, z), высоту подгоним под ландшафт позже
	var pts := [
		Vector2(-160, -120), Vector2(-40, -170), Vector2(90, -150),
		Vector2(170, -60), Vector2(150, 60), Vector2(60, 150),
		Vector2(-80, 160), Vector2(-170, 60),
	]
	for p in pts:
		curve.add_point(Vector3(p.x, 0, p.y))
	curve.add_point(Vector3(pts[0].x, 0, pts[0].y))  # замыкаем
	# Сглаживаем
	for i in range(curve.point_count):
		curve.set_point_in(i, Vector3.ZERO)
		curve.set_point_out(i, Vector3.ZERO)
	add_ribbon(curve, ROAD_WIDTH, Color(0.12, 0.12, 0.13))


func build_drift_pad() -> void:
	# Большой круглый бетонный диск
	var pad := CSGCylinder3D.new()
	pad.radius = 55.0
	pad.height = 0.2
	pad.position = Vector3(0, 0.1, 0)
	pad.material = make_mat(Color(0.35, 0.35, 0.37))
	add_child(pad)
	# Коллизия диска
	var body := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var cyl := CylinderShape3D.new()
	cyl.radius = 55.0
	cyl.height = 0.2
	shape.shape = cyl
	shape.position = pad.position
	body.add_child(shape)
	add_child(body)


func build_ramps() -> void:
	# Два трамплина на прямой перед дрифт-площадкой
	for i in range(2):
		var ramp := CSGBox3D.new()
		ramp.size = Vector3(14, 1.2, 10)
		ramp.position = Vector3(-60 + i * 40, 0.6, 90)
		ramp.rotation_degrees.x = -12
		ramp.material = make_mat(Color(0.8, 0.5, 0.1))
		add_child(ramp)
		var body := StaticBody3D.new()
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = ramp.size
		shape.shape = box
		shape.transform = ramp.transform
		body.add_child(shape)
		add_child(body)


func build_bridge() -> void:
	# Мост через "озеро" (впадину с водой) на севере карты
	var deck := CSGBox3D.new()
	deck.size = Vector3(60, 1.0, 12)
	deck.position = Vector3(0, 6.0, -210)
	deck.material = make_mat(Color(0.5, 0.4, 0.3))
	add_child(deck)
	var body := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = deck.size
	shape.shape = box
	shape.position = deck.position
	body.add_child(shape)
	add_child(body)
	# Опоры
	for x in [-25, 25]:
		var pillar := CSGBox3D.new()
		pillar.size = Vector3(2, 6, 10)
		pillar.position = Vector3(x, 3.0, -210)
		pillar.material = make_mat(Color(0.4, 0.32, 0.24))
		add_child(pillar)


func add_ribbon(curve: Curve3D, width: float, color: Color) -> void:
	var poly := CSGPolygon3D.new()
	poly.mode = CSGPolygon3D.MODE_DEPTH
	poly.depth = 0.1
	poly.path_curve = curve
	poly.path_interval = 2.0
	poly.path_rotation = CSGPolygon3D.PATH_ROTATION_NONE
	# Поперечное сечение ленты: от -w/2 до +w/2 по X
	var w := width * 0.5
	poly.polygon = PackedVector2Array([Vector2(-w, 0), Vector2(w, 0), Vector2(w, 0.1), Vector2(-w, 0.1)])
	poly.material = make_mat(color)
	poly.position.y = ROAD_LIFT
	add_child(poly)


func make_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.9
	return m
